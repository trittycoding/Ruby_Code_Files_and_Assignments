require_relative 'ar.rb'

# Delete one of the products you created prior
product_to_delete = Product.where(name: 'Cheese').first
product_to_delete.destroy
puts product_to_delete.inspect
