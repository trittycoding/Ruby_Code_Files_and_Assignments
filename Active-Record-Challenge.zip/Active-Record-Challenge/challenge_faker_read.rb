require_relative 'ar.rb'

# Grab all categories and display their names, in addition
# display all their associated products (name and price)

categories = Category.all
amount_of_categories = categories.size

categories.each do |category|
  puts "Name of Category - #{category.name}"
  puts '---List of Products ---'
  products_per_category = category.products.all
  products_per_category.each do |product|
    puts "---Name: #{product.name}, Price: #{product.price}"
  end
  puts ''
end
