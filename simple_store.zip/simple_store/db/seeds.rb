# Part 2 - Populating DB using CSV
require "csv"


# Empty the db prior to building
Product.delete_all
Category.delete_all

# Build path and file name
filename = Rails.root.join("db/products.csv")

# Read from file
csv_data = File.read(filename)

# Parse the resulting string information from the CSV
products = CSV.parse(csv_data, headers: true, encoding: "utf-8")

# Enter parsed data into DB
products.each do |prod|
  category = Category.find_or_create_by(name: prod["category"])

  # If the category is valid, create the product
  if category&.valid?
    product = category.products.create(
      title: prod["name"],
      price: prod["price"],
      description: prod["description"],
      stock_quantity: prod["stock quantity"]
    )
    puts "Invalid product - #{prod["name"]}" unless product&.valid?
  else
    puts "Invalid category #{prod["category"]} for product #{prod["name"]}"
  end
end

# Part 1 - Using Faker to populate DB
# 676.times do
#   product = Product.create(
#     title: Faker::Device.model_name,
#     price: Faker::Commerce.price,
#     stock_quantity: Faker::Number.within(range: 1..10)
#   )
# end
puts "Created #{Category.count} categories from script"
puts "Created #{Product.count} products from script"

