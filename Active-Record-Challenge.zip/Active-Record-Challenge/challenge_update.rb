require_relative 'ar.rb'

# Find all products with quantities over 40, add 1
products_quantity_over_40 = Product.where('stock_quantity > 40')
products_quantity_over_40.each do |product|
  puts product.inspect
  product.stock_quantity += 1
  puts product.inspect
  puts ''
end
