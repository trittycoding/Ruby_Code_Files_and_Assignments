require_relative 'ar.rb'

# Create ten new categories using faker - name, description
10.times do
  new_category = Category.new(name: Faker::Commerce.department, description: Faker::Commerce.department)
  new_category.save
  10.times do
    new_product = new_category.products.build(name: Faker::Food.ingredient,
                                              description: Faker::Food.description,
                                              price: Faker::Number.decimal(l_digits: 2, r_digits: 2),
                                              stock_quantity: Faker::Number.between(from: 1, to: 100))
    new_product.save
    puts new_product.inspect
  end
end
