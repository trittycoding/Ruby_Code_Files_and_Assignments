require_relative 'ar.rb'

# Product Count - 77 by default
number_of_products = Product.count
puts "There are #{number_of_products} in the products table."

# 1 - Read any product from the table and inspect
random_product = Product.all

# Total number of products
size = random_product.size
puts "Number of products - #{size}"

# Product Inspect
puts "Random product chosen - #{random_product[rand(1..size)].inspect}"

# Output: {Random product chosen - id: 167, name: "Konbu",
# description: "2 kg box", price: 0.6e1, stock_quantity: 24, category_id: 8}

# Names of products above $10 w/ names beginning with 'C'
products_above_ten_start_with_c = Product.where('(price > 10) AND (name LIKE "c%")')
products_above_ten_start_with_c.each do |product|
  puts product.name
end

# Products that are in low stock (Stock < 5)
products_with_low_stock = Product.where('stock_quantity < 5')
puts "Number of products with quantity less than five - #{products_with_low_stock.size}"

# Categories table
categories = Category.all
categories.each do |category|
  puts category.name
end

# Categories available -
# Beverages
# Condiments
# Confections
# Dairy Products
# Grains/Cereals
# Meat/Poultry
# Produce
# Seafood

# Grab a category name according to the id
product_created_category = Product.where(name: 'Oatz').first
product_created_category.category_id = 7.to_i
category_name = Category.where(id: product_created_category.category.id).first
puts category_name.name

# Create a new product based off of the category table result
new_product = category_name.products.build(name: 'Chipz',
                                           description: 'Potato chips',
                                           price: 2.00.to_i,
                                           stock_quantity: 5.to_i)
new_product.save
puts new_product.inspect
