require_relative 'ar.rb'

# Method 1 - Creating blank object in object space
new_product = Product.new
new_product.name = 'Oatz'
new_product.description = 'Some oats'
new_product.price = 5.25.to_i
new_product.stock_quantity = 3.to_i
new_product.category_id = 5.to_i
new_product.save
puts new_product.inspect

# Method 2 - setting properties as key/value pairs
ducky = Product.new(name: 'Duck',
                    description: 'Duck meat',
                    price: 129.99.to_i,
                    stock_quantity: 7.to_i,
                    category_id: 6.to_i)
ducky.save

# Method 3 - create and persist
cheese = Product.create(name: 'Cheese',
                        description: 'Shredded cheese',
                        price: 9.99.to_i,
                        stock_quantity: 10.to_i,
                        category_id: 4.to_i)
puts cheese.inspect

# Create an object with fields that purposely fail validation
# Should fail validation as multiple fields missing values, name < 3 length
blank = Product.new(name: 'ha')
blank.save

# Save the product and log the errors
blank.errors.messages.each do |column, errors|
  errors.each do |error|
    puts "The #{column} column has the error of: #{error}"
  end
end
