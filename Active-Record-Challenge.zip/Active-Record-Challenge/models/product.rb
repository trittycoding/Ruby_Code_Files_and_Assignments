# This AR object is linked with the products table.
# A product has a many to one relationship with a category.
# The products table has a category_id foreign key.
# In other words, a product belongs to a category.

class Product < ActiveRecord::Base
  validates :name, uniqueness: true, length: { minimum: 3 }, presence: true
  validates :description, :price, :stock_quantity, :name, presence: true
  belongs_to :category
end
